package com.example.sender;

import org.junit.Test;

public class SendTest {


    @Test
    public void send() {
        new Send().send();
    }
}