package com.example.demo.pojo;

import lombok.Data;

@Data
public class UserJob {

    private Integer jid;
    private String jname;

   /* public Integer getJid() {
        return jid;
    }

    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public String getJname() {
        return jname;
    }

    public void setJname(String jname) {
        this.jname = jname;
    }*/
}
